#!/bin/bash
# Mac / Linux: bash run-tests.sh
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Install Node.js LTS from https://nodejs.org first."; exit 1; }
[ -d node_modules/playwright ] || { npm install && npx playwright install chromium; } || exit 1
node run_all.js "$@"
