KHELE SANAND - SYSTEM CHECK KIT
===============================

Yeh kit aapke dashboard ki 11 automatic jaanch karta hai (code, saari screens,
admin ke saare buttons, result ranking, backup, offline, referee lock,
WhatsApp-link mode, Live Sync aur internet jaane ke baad wapas judna).

EK BAAR KA SETUP (Windows)
1. https://nodejs.org se 'LTS' version download karke install karein (Next-Next-Finish).
2. Is zip ko unzip karein, jaise D:\khele-test-kit
3. RUN-TESTS.bat par double-click karein.
   Pehli baar 5-10 minute lagenge (test browser download hota hai). Internet chahiye.

HAR BAAR CHECK KAISE KAREIN
1. Apni nayi files (index.html, sw.js, manifest, icons) 'app' folder me daalein
   (purani files replace kar dein).
2. RUN-TESTS.bat par double-click karein. 3-5 minute me result aayega.
3. Sab hare (green) ALL CHECKS PASSED = GitHub par upload karna safe hai.
   Koi laal (red) X dikhe = upload MAT kijiye; us window ka screenshot Claude ko bhejein.

DHYAN DEIN
- Test chalte waqt dusri koi test window khuli na ho (port 8765 aur 9000 use hote hain).
- Yeh test aapke asli Firebase ya asli data ko touch nahi karta; nakli database use karta hai.
- Mac/Linux par: bash run-tests.sh
