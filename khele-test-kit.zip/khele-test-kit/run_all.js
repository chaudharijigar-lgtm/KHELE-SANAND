// Khele Sanand dashboard — full regression check.
// Usage:  node run_all.js            (checks the files in the "app" folder)
//         node run_all.js D:\path\to\folder   (checks another folder with index.html)
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os'), vm = require('vm');
const { spawn } = require('child_process');

const KIT = __dirname;
const APP = path.resolve(process.argv[2] || path.join(KIT, 'app'));
const SHOTS = path.join(os.tmpdir(), 'ks-shots') + path.sep;
fs.mkdirSync(SHOTS, { recursive: true });

const C = { ok: s => `\x1b[32m${s}\x1b[0m`, bad: s => `\x1b[31m${s}\x1b[0m`, dim: s => `\x1b[90m${s}\x1b[0m` };
let failed = 0;
const pass = t => console.log('\r\x1b[2K' + C.ok('✅ ' + t));
const fail = (t, more) => { failed++; console.log('\r\x1b[2K' + C.bad('❌ ' + t)); if (more) console.log(C.dim(more.split('\n').slice(-15).map(l => '     ' + l).join('\n'))); };

// ── 1. Syntax: every inline <script> in index.html, sw.js, manifest ──
function syntaxCheck() {
  const file = path.join(APP, 'index.html');
  if (!fs.existsSync(file)) { fail('index.html not found in ' + APP); return false; }
  const html = fs.readFileSync(file, 'utf8');
  const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g; let m, i = 0, bad = 0;
  while ((m = re.exec(html))) { i++; if (!m[1].trim()) continue;
    try { new vm.Script(m[1], { filename: 'index.html script #' + i }); } catch (e) { bad++; fail('Code error in script #' + i + ': ' + e.message); } }
  try { new vm.Script(fs.readFileSync(path.join(APP, 'sw.js'), 'utf8')); } catch (e) { bad++; fail('sw.js: ' + e.message); }
  try { JSON.parse(fs.readFileSync(path.join(APP, 'manifest.webmanifest'), 'utf8')); } catch (e) { bad++; fail('manifest.webmanifest: ' + e.message); }
  if (!bad) pass('Code syntax (no broken scripts)');
  return !bad;
}

// ── 2. Local web server for the app (port 8765) ──
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.json': 'application/json' };
function startServer() {
  return new Promise(res => {
    const srv = http.createServer((req, rs) => {
      let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html';
      const f = path.join(APP, path.normalize(p).replace(/^([\\/])+/, ''));
      if (!f.startsWith(APP) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { rs.writeHead(404); return rs.end('not found'); }
      rs.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      fs.createReadStream(f).pipe(rs);
    }).listen(8765, () => res(srv));
    srv.on('error', e => { console.log(C.bad('Port 8765 is busy — close other test windows and try again.')); process.exit(1); });
  });
}

// ── 3. Run one browser test and check its output ──
function runTest(title, script, arg, mustHave) {
  return new Promise(res => {
    const args = [path.join(KIT, 'tests', script)]; if (arg) args.push(arg);
    const ch = spawn(process.execPath, args, { cwd: KIT, env: { ...process.env, KS_SHOTS: SHOTS } });
    let out = ''; ch.stdout.on('data', d => out += d); ch.stderr.on('data', d => out += d);
    const timer = setTimeout(() => ch.kill(), 10 * 60 * 1000);
    ch.on('close', () => {
      clearTimeout(timer);
      const problems = [];
      if (/PAGEERROR|CONSOLE |errors \[[^\]]|errs \[[^\]]|Error:|Unhandled/.test(out)) problems.push('error found');
      mustHave.forEach(r => { if (!new RegExp(r).test(out)) problems.push('missing: ' + r); });
      problems.length ? fail(title, problems.join('\n') + '\n' + out) : pass(title);
      res();
    });
  });
}

(async () => {
  console.log('Khele Sanand — system check\nApp folder: ' + APP + '\n');
  if (!syntaxCheck()) { console.log(C.bad('\nFix the code errors above first.')); process.exit(1); }
  const srv = await startServer();
  const mock = spawn(process.execPath, [path.join(KIT, 'tests', 'mockfb.js')], { stdio: 'ignore' });
  await new Promise(r => setTimeout(r, 1200));
  const tests = [
    ['Screens on LED + phone',           'sweep.js',  '',        ['=== led ===', '=== phone ===', 'no errors']],
    ['Admin buttons (cancel)',           'fuzz.js',   'dismiss', ['no errors']],
    ['Admin buttons (confirm)',          'fuzz.js',   'accept',  ['no errors']],
    ['Result ranking & time checks',     'logic2.js', '',        ['A5:6\\.50m:1', 'A2:1\\.23\\?:999:INVALID', '1:75\\.00=NaN']],
    ['Olympic result format',            'oly.js',    '',        ['ok  "12.341" → "12.35"', 'ok  "8.95m" → "8.95 m"', 'ok  "2:01:09"']],
    ['New event types (30m to Medicine Ball)', 'events.js', '',  ['Vertical Jump=field,', 'Medicine Ball Throw=field', '30m=track', 'A2:0\\.52 m:1']],
    ['Athlete photo links (Drive / web)', 'photo.js',  '',        ['"same":"saved"', '"nocors":"link"', '"folder":"none"', '"imported":5']],
    ['Drive API photos, Excel hyperlinks, ZIP photos', 'photo2.js', '', ['"good":"saved"', '"setupHelp":true', '"retryBtn":true', 'Link Behind Text=https://drive', 'Formula Link=https://drive', 'Name Hyperlinked=\\n', '"bib101":true', '"name":true', '"formName":true', 'button true']],
    ['Certificate design (merit / participation / custom)', 'cert.js', '', ['"card":true', '"saved":"blue\\|Rajesh Patel', '"father":"Mahesh Thakor"', '"pushHasFather":false', '"preview":"3\\|true\\|true"', '"merit":true', '"part":true', '"blank":true', '"venue":true', '"custom":true', '"meetName":"Khele Sanand Athletics Meet 2027"']],
    ['Several events live at once', 'multilive.js', '', ['"live":"track,field,field"', '"split":"live\\|true\\|3\\|1"', '"slides":"3\\|2\\|1"', '"liveOnly":3', '"pub":2', '"rotates":3', '"ledPinned":true', '"pinSlides":1', '"afterSwitch":"3\\|true\\|live"', '"finished":"completed\\|2"', '"card":true']],
    ['Multi-live edge cases + Live Sync screens', 'multilive2.js', '', ['"aBig":true', '"aLed":true', '"bSplit":true', '"bPin":true', '"bUnpin":true', '"bFinalShown":true']],
    ['Backup / restore',                 'bk.js',     '',        ['images: 2']],
    ['Offline / install',                't.js',      '',        ['"ctrl": true']],
    ['Referee thank-you lock',           'ty.js',     '',        ['link after reload \\{"ty":true', 'fb after reload \\{"ty":true', 'provisional banner\\? false']],
    ['WhatsApp-link + same-device mode', 'modes.js',  '',        ['Long Jump.*control got [1-9].*LED tab got [1-9]', 'LOCAL.*LED shows it: true']],
    ['Live Sync',                        'live.js',   '',        ['thank-you green: true', 'LED has results: true', 'auto-closed on control: true']],
    ['Live Sync after internet outage',  'live.js',   'outage',  ['thank-you green: true', 'LED has results: true']],
  ];
  for (const [t, s, a, m] of tests) { process.stdout.write(C.dim('   running: ' + t + ' …\r')); await runTest(t, s, a, m); }
  mock.kill(); srv.close();
  console.log('\n' + (failed ? C.bad(`${failed} CHECK(S) FAILED — do not upload this version.`) : C.ok('ALL CHECKS PASSED — safe to upload.')));
  process.exit(failed ? 1 : 0);
})();
