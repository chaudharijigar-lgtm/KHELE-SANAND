@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Khele Sanand - System Check
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js install nahi hai. https://nodejs.org se LTS version install karein, phir dobara chalayein.
  echo.
  pause
  exit /b 1
)
if not exist "node_modules\playwright" (
  echo Pehli baar setup ho raha hai - 5 se 10 minute, internet chahiye...
  call npm install
  if errorlevel 1 ( pause & exit /b 1 )
  call npx playwright install chromium
  if errorlevel 1 ( pause & exit /b 1 )
)
node run_all.js %*
echo.
pause
