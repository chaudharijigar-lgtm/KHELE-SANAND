// Big View → back to the screen it was opened from (control panel / dashboard / home), keys, control-room Dashboard button
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = []; const ctx = await b.newContext({ viewport: { width: 1600, height: 900 } }); const p = await ctx.newPage();
  p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.accept());
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(700);
  await p.evaluate(() => { localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); loadDemoData(); });
  const cur = () => p.evaluate(() => curScreen());
  const out = {};
  // 1. control panel → LED dashboard → Big View → BACK → dashboard → ← Control Panel
  await p.evaluate(() => { showScreen('admin'); showPage('page-athletes'); }); await p.waitForTimeout(300);
  await p.evaluate(() => showScreen('led')); await p.waitForTimeout(300);
  out.ledBackLabel = await p.evaluate(() => document.querySelector('#led-screen .led-back').textContent);
  await p.click('#led-screen button[onclick="showScreen(\'focus\')"]'); await p.waitForTimeout(400);
  out.inBig = await cur();
  await p.mouse.move(400, 400); await p.waitForTimeout(200);
  out.backVisible = await p.evaluate(() => getComputedStyle(document.querySelector('#focus-screen .fv-ctrl')).opacity);
  out.backLabel = await p.evaluate(() => document.querySelector('#focus-screen .fv-back').textContent);
  await p.click('#focus-screen .fv-back'); await p.waitForTimeout(300); out.afterBack = await cur();
  await p.click('#led-screen .led-back'); await p.waitForTimeout(300); out.afterLedBack = await cur();
  out.samePage = await p.evaluate(() => document.getElementById('page-athletes').classList.contains('active'));
  // 2. control panel → Preview Big View here → BACK returns to the control panel
  await p.evaluate(() => { showPage('page-screen'); }); await p.click('#page-screen button[onclick="showScreen(\'focus\')"]'); await p.waitForTimeout(400);
  out.previewLabel = await p.evaluate(() => document.querySelector('#focus-screen .fv-back').textContent);
  out.previewDash = await p.evaluate(() => !!document.querySelector('#focus-screen .fv-ctrl button[onclick="showScreen(\'led\')"]'));
  await p.keyboard.press('Escape'); await p.waitForTimeout(300); out.escBack = await cur();
  // 3. home → Big View → BACK → home ; D key → dashboard
  await p.evaluate(() => showScreen('launcher')); await p.evaluate(() => showScreen('focus')); await p.waitForTimeout(300);
  await p.keyboard.press('d'); await p.waitForTimeout(300); out.dKey = await cur();
  await p.keyboard.press('b'); await p.waitForTimeout(300); out.bKey = await cur();
  await p.keyboard.press('Backspace'); await p.waitForTimeout(300); out.bsBack = await cur();
  // controls hide again
  await p.evaluate(() => showScreen('focus')); await p.waitForTimeout(6500);
  out.hidesAgain = await p.evaluate(() => getComputedStyle(document.querySelector('#focus-screen .fv-ctrl')).opacity);
  // 4. control room top bar: Big View / Dashboard buttons switch the ground screens
  await p.evaluate(() => { showScreen('admin'); }); await p.waitForTimeout(300);
  await p.click('#ab-big'); out.viewBig = await p.evaluate(() => getDisplay().view + '|' + $('ab-big').classList.contains('primary'));
  await p.click('#ab-dash'); out.viewDash = await p.evaluate(() => getDisplay().view + '|' + $('ab-dash').classList.contains('primary'));
  // a second tab (LED) follows the control room both ways
  const led = await ctx.newPage(); led.on('pageerror', e => errs.push('led ' + e.message)); await led.goto('http://localhost:8765/index.html'); await led.waitForTimeout(600);
  await led.evaluate(() => showScreen('led'));
  await p.click('#ab-big'); await led.waitForTimeout(1200); out.ledToBig = await led.evaluate(() => curScreen());
  await p.click('#ab-dash'); await led.waitForTimeout(1200); out.ledToDash = await led.evaluate(() => curScreen());
  console.log(JSON.stringify(out)); console.log('errs', errs); await b.close();
})();
