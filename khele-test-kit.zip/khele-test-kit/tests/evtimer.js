// Multi-live: every live event has its own timer (control, LED, Big View split + slideshow, public, referee, Live Sync)
const { chromium } = require('playwright');
const init = () => { window.KS_AUTH_BASE = { signUp: 'http://localhost:9000/signUp', refresh: 'http://localhost:9000/token' }; window.KS_ALLOW_ANY_DB = true; };
const secs = t => { if (!t) return -1; const p = t.split(':').map(Number); return p.reduce((a, b) => a * 60 + b, 0); };
(async () => {
  const b = await chromium.launch(); const errs = [];
  const mk = async (vp) => { const ctx = await b.newContext({ viewport: vp || { width: 1600, height: 900 } }); await ctx.addInitScript(init); const p = await ctx.newPage(); p.on('dialog', d => d.accept()); p.on('pageerror', e => errs.push(e.message)); return p; };
  const c = await mk(); await c.goto('http://localhost:8765/index.html'); await c.waitForTimeout(700);
  const info = await c.evaluate(async () => {
    localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); localStorage.setItem('ks_control', '1'); loadDemoData();
    const s = getStore(); const evs = s.events.filter(e => e.status !== 'completed' && e.type !== 'ceremony');
    const tr = evs.find(e => e.type === 'track'), fl = evs.find(e => e.type === 'field');
    setSync({ mode: 'firebase', dbUrl: 'http://localhost:9000', room: 'ET' + Date.now(), role: 'control', apiKey: 'k' }); await connectSync();
    setLiveEvent(tr.id); addAlsoLive(fl.id); showScreen('admin'); showPage('page-run'); renderRunOfShow();
    return { tr: tr.id, fl: fl.id, led: displayUrl('led'), big: displayUrl('big'), pub: displayUrl('public'), ref: getRefUrl(eventById(getStore(), fl.id)) };
  });
  const out = {};
  out.cardStart = await c.evaluate(id => !!document.querySelector(`#ml-card button[onclick="evTimerStart(${id})"]`), info.fl);
  await c.click(`#ml-card button[onclick="evTimerStart(${info.fl})"]`); await c.waitForTimeout(2600);
  out.cardTime = secs(await c.evaluate(id => document.querySelector(`#ml-card .evt-t[data-evt="${id}"]`).textContent, info.fl)) >= 2;
  out.mainStill0 = await c.evaluate(() => fmtElapsed(elapsedMs()));
  // Big View split on control laptop
  await c.evaluate(() => { setLiveView('split'); showScreen('focus'); }); await c.waitForTimeout(800);
  out.splitTimer = secs(await c.evaluate(id => (document.querySelector(`#fv-stage .evt-t[data-evt="${id}"]`) || {}).textContent, info.fl)) >= 2;
  // slideshow, pinned on the also-live event
  await c.evaluate(id => { setLiveView('rotate'); pinScreen(id); renderFocus(true); }, info.fl); await c.waitForTimeout(800);
  out.slideTimer = secs(await c.evaluate(id => (document.querySelector(`#fv-stage .evt-t[data-evt="${id}"]`) || {}).textContent, info.fl)) >= 2;
  // LED on the same laptop, pinned on the also-live event
  await c.evaluate(() => showScreen('led')); await c.waitForTimeout(1000);
  out.ledLocal = await c.evaluate(() => [$('led-screen').classList.contains('alt-timer'), $('d-elapsed').textContent, getComputedStyle($('d-elapsed').parentElement).visibility].join('|'));
  // other devices over Live Sync
  const led = await mk({ width: 1920, height: 1080 }); await led.goto(info.led); await led.waitForTimeout(4000);
  out.ledSync = await led.evaluate(() => [$('led-screen').classList.contains('alt-timer'), $('d-elapsed').textContent].join('|'));
  const big = await mk({ width: 1920, height: 1080 }); await big.goto(info.big); await big.waitForTimeout(4000);
  out.bigSync = await big.evaluate(id => (document.querySelector(`#fv-stage .evt-t[data-evt="${id}"]`) || {}).textContent || 'none', info.fl);
  const pub = await mk({ width: 390, height: 844 }); await pub.goto(info.pub); await pub.waitForTimeout(4000);
  out.pubSync = await pub.evaluate(id => (document.querySelector(`#public-screen .evt-t[data-evt="${id}"]`) || {}).textContent || 'none', info.fl);
  const ref = await mk({ width: 390, height: 844 }); await ref.goto(info.ref); await ref.waitForTimeout(4000);
  out.refTimer = await ref.evaluate(() => { const e = document.getElementById('rp-elapsed-ev') || document.getElementById('rp-elapsed'); return e ? e.id + '|' + e.textContent : 'none'; });
  // pause keeps the time; main still independent
  await c.evaluate(id => { showScreen('admin'); showPage('page-run'); evTimerPause(id); }, info.fl); await c.waitForTimeout(400);
  const p1 = await c.evaluate(id => fmtElapsed(evElapsed(getStore(), id)), info.fl); await c.waitForTimeout(1200);
  out.paused = p1 === await c.evaluate(id => fmtElapsed(evElapsed(getStore(), id)), info.fl);
  // swap: the field event becomes MAIN → its time moves to the big timer; old main (track, started) keeps its own
  await c.evaluate(() => startTimer()); await c.waitForTimeout(1500);
  out.swap = await c.evaluate(ids => { setLiveEvent(ids.fl); const s = getStore(); return [s.liveEventId === ids.fl, elapsedMs() >= 2000, (s.alsoLive || []).includes(ids.tr), evElapsed(s, ids.tr) >= 1000].join('|'); }, info);
  console.log(JSON.stringify(out)); console.log('errs', errs); await b.close();
})();
