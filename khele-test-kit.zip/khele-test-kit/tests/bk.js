const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const ctx=await b.newContext(); const p = await ctx.newPage(); p.on('dialog',d=>d.accept());
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  const json = await p.evaluate(() => { loadDemoData(); saveImages(['data:image/png;base64,AAAA','data:image/png;base64,BBBB']);
    let got=null; const o=downloadFile; downloadFile=(n,c)=>{ got=c; }; backupDataOnly(); downloadFile=o; return got; });
  const has = JSON.parse(json).__images; console.log('backup has images:', has&&has.length);
  // fresh browser restores it
  const p2 = await (await b.newContext()).newPage(); p2.on('dialog',d=>d.accept()); p2.on('pageerror',e=>errs.push('p2 '+e.message));
  await p2.goto('http://localhost:8765/index.html'); await p2.waitForTimeout(800);
  require('fs').writeFileSync(process.env.KS_SHOTS+'bk.json', json);
  await p2.evaluate(()=>{ const i=document.createElement('input'); i.type='file'; i.id='bkin'; i.onchange=e=>importBackup(e); document.body.appendChild(i); });
  await p2.setInputFiles('#bkin',process.env.KS_SHOTS+'bk.json');
  await p2.waitForTimeout(1500);
  console.log('restored:', await p2.evaluate(()=>({events:getStore().events.length, athletes:getStore().athletes.length, images:getImages().length, leak:'__images' in getStore()})));
  console.log('errs',errs); await b.close();
})();
