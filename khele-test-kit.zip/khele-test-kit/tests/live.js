const { chromium } = require('playwright');
const SP=process.env.KS_SHOTS;
const init = () => { window.KS_AUTH_BASE={signUp:'http://localhost:9000/signUp',refresh:'http://localhost:9000/token'}; window.KS_ALLOW_ANY_DB=true; };
const OUTAGE = process.argv[2]==='outage';
(async () => {
  const b = await chromium.launch(); const errs=[];
  const mk = async (tag, vp) => { const ctx=await b.newContext({viewport:vp||{width:1280,height:800}}); await ctx.addInitScript(init); const p=await ctx.newPage();
    p.on('dialog',d=>d.accept()); p.on('pageerror',e=>errs.push(tag+': '+e.message)); p.on('console',m=>{ if(m.type()==='error'&&!/Failed to load resource|ERR_/.test(m.text())) errs.push(tag+' console: '+m.text().slice(0,200)); }); return p; };
  const ctl = await mk('control');
  await ctl.goto('http://localhost:8765/index.html'); await ctl.waitForTimeout(700);
  await ctl.evaluate(async()=>{ localStorage.setItem('ks_pin',pinHash('1234')); sessionStorage.setItem('ks_admin_ok','1'); loadDemoData();
    s=getStore(); s.settings.refAutoClose=true; saveStore(s);
    localStorage.setItem('ks_control','1');
    setSync({mode:'firebase',dbUrl:'http://localhost:9000',room:'T'+Date.now(),role:'control',apiKey:'k'}); await connectSync(); });
  await ctl.waitForTimeout(1500);
  const info = await ctl.evaluate(()=>{ const s=getStore(); const ev=s.events.find(e=>e.type==='track'&&e.status!=='completed'&&s.athletes.some(a=>a.event===e.name)); return {status:_syncStatus, owner:_isOwner, led:displayUrl('led'), ref:getRefUrl(ev), ev:ev.name, evId:ev.id}; });
  console.log('control', info.status, 'owner', info.owner, 'event', info.ev);
  const led = await mk('led',{width:1920,height:1080});
  await led.goto(info.led); await led.waitForTimeout(2500);
  console.log('led status', await led.evaluate(()=>_syncStatus), 'events on LED', await led.evaluate(()=>getStore().events.length));
  if (OUTAGE) {
    await (await fetch('http://localhost:9000/__outage?n=6')).json();
    await led.waitForTimeout(8000);
    console.log('after outage: LED stream states', await led.evaluate(()=>_streams.map(s=>s.readyState).join(',')), 'status', await led.evaluate(()=>_syncStatus));
  }
  const ph = await mk('phone',{width:390,height:844});
  await ph.goto(info.ref); await ph.waitForTimeout(2500);
  const n = await ph.evaluate(()=>{ let i=0; document.querySelectorAll('#ref-athletes-container input[id^="ref-t-"]').forEach(x=>{ x.value=String(1100+(i++)*13); }); return i; });
  console.log('phone inputs', n, 'phone status', await ph.evaluate(()=>_syncStatus));
  await ph.evaluate(()=>submitRefereeResults());
  let green=false; for(let i=0;i<20&&!green;i++){ await ph.waitForTimeout(1000); green = await ph.evaluate(()=>/Sent to the control room/.test(document.body.innerText)); }
  console.log('phone thank-you green:', green);
  let ledHas=false; for(let i=0;i<(OUTAGE?40:15)&&!ledHas;i++){ await led.waitForTimeout(1000); ledHas = await led.evaluate(n=>(getStore().results[n]||[]).length>0, info.ev); }
  console.log('ctl dbg', await ctl.evaluate(()=>JSON.stringify({inbox:Object.keys(_trees.inbox||{}), streams:_streams.map(x=>x.url.replace(/\?.*/,'')+':'+x.readyState), st:_syncStatus, role:getSync().role})));
  console.log('control has results:', await ctl.evaluate(n=>(getStore().results[n]||[]).length, info.ev), '| LED has results:', ledHas);
  await ph.waitForTimeout(3000);
  console.log('ref access auto-closed on control:', await ctl.evaluate(id=>refClosed(id), info.evId));
  await ph.screenshot({path:SP+'live-phone.png'}); await led.screenshot({path:SP+'live-led.png'});
  console.log('errors', errs); await b.close();
})();
