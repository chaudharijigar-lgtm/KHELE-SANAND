// Google Drive photos via the official Drive API (simulated Google), Excel hyperlinks, and ZIP photo upload
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
const FX = path.join(__dirname, 'fixtures');
(async () => {
  const png = fs.readFileSync(path.join(__dirname, '..', 'app', 'icon-192.png'));
  const b = await chromium.launch(); const ctx = await b.newContext(); const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.accept());
  // pretend to be Google: GOOD* ids are public, SETUP* = Drive API off, PRIVATE* = not shared
  await ctx.route('https://www.googleapis.com/drive/v3/files/**', route => {
    const u = new URL(route.request().url()); const id = decodeURIComponent(u.pathname.split('/').pop());
    const cors = { 'Access-Control-Allow-Origin': '*' };
    if (!u.searchParams.get('key')) return route.fulfill({ status: 403, headers: cors, contentType: 'application/json', body: JSON.stringify({ error: { message: 'The request is missing a valid API key.', status: 'PERMISSION_DENIED' } }) });
    if (id.startsWith('GOOD')) return route.fulfill({ status: 200, headers: cors, contentType: 'image/png', body: png });
    if (id.startsWith('SETUP')) return route.fulfill({ status: 403, headers: cors, contentType: 'application/json', body: JSON.stringify({ error: { message: 'Google Drive API has not been used in project 123 before or it is disabled.', errors: [{ reason: 'accessNotConfigured' }], status: 'PERMISSION_DENIED' } }) });
    return route.fulfill({ status: 404, headers: cors, contentType: 'application/json', body: JSON.stringify({ error: { message: 'File not found: ' + id, errors: [{ reason: 'notFound' }] } }) });
  });
  await ctx.route(/drive\.google\.com\/thumbnail|lh3\.googleusercontent\.com/, r => r.abort());
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  await p.evaluate(() => { localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); loadDemoData(); localStorage.setItem('ks_drive_key', 'AIzaTEST'); });

  // 1) Drive API: good / API switched off / not shared
  const api = await p.evaluate(async () => {
    const s = getStore(); const ev = s.events[0].name; _bulk.kind = 'athletes';
    _bulk.preview = [['Drive Good', 'https://drive.google.com/file/d/GOODID1111111/view?usp=sharing'], ['Drive Setup', 'https://drive.google.com/file/d/SETUPID222222/view'], ['Drive Private', 'https://drive.google.com/open?id=PRIVATE333333']]
      .map(([n, u]) => ({ status: 'ok', data: { name: n, team: 'Sanand', event: ev, photo: u } }));
    bulkImport();
    for (let i = 0; i < 120 && !(document.getElementById('photo-job') || {}).textContent?.includes('done'); i++) await new Promise(r => setTimeout(r, 250));
    const st = getStore(); const g = n => { const a = st.athletes.find(x => x.name === n); const v = a && PhotoDB.cache[photoKey(a)]; return v ? (v.startsWith('data:image/jpeg') ? 'saved' : 'link') : 'none'; };
    const box = document.getElementById('photo-job').innerText.replace(/\s+/g, ' ');
    return { good: g('Drive Good'), setup: g('Drive Setup'), priv: g('Drive Private'), setupHelp: /Google Drive API/.test(box) && /Enable/.test(box), retryBtn: /Retry 2/.test(box), privMsg: /Anyone with the link/.test(box) };
  });
  console.log('API', JSON.stringify(api));

  // 2) Excel with hyperlinks
  await p.evaluate(() => { const i = document.createElement('input'); i.type = 'file'; i.id = 'xl'; document.body.appendChild(i); });
  await p.setInputFiles('#xl', path.join(FX, 'athletes-links.xlsx'));
  const xl = await p.evaluate(async () => { const rows = await readXlsx(document.getElementById('xl').files[0]); return rows.slice(1).map(r => r[0] + '=' + (r[4] || '')).join(' | '); });
  console.log('XLSX', xl);

  // 3) ZIP of photos matched by bib / name
  await p.evaluate(() => { const i = document.createElement('input'); i.type = 'file'; i.id = 'zp'; i.multiple = true; i.onchange = e => importPhotoFiles(e); document.body.appendChild(i); document.getElementById('photo-job')?.remove(); });
  await p.setInputFiles('#zp', path.join(FX, 'photos.zip'));
  for (let i = 0; i < 60; i++) { const t = await p.evaluate(() => (document.getElementById('photo-job') || {}).textContent || ''); if (/Photos imported/.test(t)) break; await p.waitForTimeout(250); }
  const zp = await p.evaluate(() => { const s = getStore(); const has = n => { const a = s.athletes.find(x => x.name === n); return !!(a && PhotoDB.cache[photoKey(a)]); };
    const box = document.getElementById('photo-job').innerText.replace(/\s+/g, ' ');
    return { bib101: has('Rahul Patel'), name: has('Arjun Mehta'), formName: has('Vishal Rana'), saved: (box.match(/✅ (\d+)/) || [])[1], unmatched999: /999\.jpg/.test(box), heic: /HEIC/.test(box) }; });
  console.log('ZIP', JSON.stringify(zp));
  // the button is on the Athletes page
  await p.evaluate(() => { showScreen('admin'); showPage('page-athletes'); }); await p.waitForTimeout(3500);
  console.log('button', await p.evaluate(() => !!document.getElementById('photo-zip-btn')));
  console.log('errs', errs); await b.close();
})();
