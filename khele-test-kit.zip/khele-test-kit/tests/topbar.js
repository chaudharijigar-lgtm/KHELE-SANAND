const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const errs=[];
 for (const [w,light] of [[1366,true],[1920,true],[1280,false],[1100,true]]) { const p=await (await b.newContext({viewport:{width:w,height:720}})).newPage(); p.on('pageerror',e=>errs.push(e.message)); p.on('dialog',d=>d.accept());
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(600);
  await p.evaluate((light)=>{ localStorage.setItem('ks_pin',pinHash('1234')); sessionStorage.setItem('ks_admin_ok','1'); localStorage.setItem('ks_ops_theme',light?'light':'dark'); applyOpsTheme(); loadDemoData(); showScreen('admin'); },light);
  await p.waitForTimeout(500);
  const fit=await p.evaluate(()=>{ const t=document.querySelector('#admin-screen .admin-topbar'); return t.scrollWidth<=t.clientWidth+1; });
  await p.click('#ab-more'); await p.waitForTimeout(300);
  await p.screenshot({path:(process.env.KS_SHOTS||require('os').tmpdir()+'/')+'topbar-'+w+'.png',clip:{x:0,y:0,width:w,height:420}});
  const n=await p.evaluate(()=>document.querySelectorAll('#ab-menu button').length);
  // menu items work: Print Centre opens, menu closes
  await p.click('#ab-menu button:has-text("Print Centre")'); await p.waitForTimeout(400);
  const pc=await p.evaluate(()=>!!document.querySelector('.modal-overlay.open'));
  console.log(w,'fits:',fit,'menu items:',n,'print opens:',pc, 'menu closed:', await p.evaluate(()=>!$('ab-menu').classList.contains('open')));
  if(w===1366){ await p.evaluate(()=>document.querySelectorAll('.modal-overlay.open').forEach(m=>m.classList.remove('open')));
    await p.click('#ab-more'); await p.click('#ab-menu button:has-text("panels")'); await p.waitForTimeout(300); console.log(' theme now', await p.evaluate(()=>opsTheme()));
    await p.click('#ab-big'); console.log(' big', await p.evaluate(()=>getDisplay().view+'|'+$('ab-big').classList.contains('primary')));
    await p.click('#ab-dash'); console.log(' dash', await p.evaluate(()=>getDisplay().view+'|'+$('ab-dash').classList.contains('primary')));
    await p.click('#ab-more'); await p.click('#ab-menu button:has-text("Lock")'); await p.waitForTimeout(400); console.log(' locked ->', await p.evaluate(()=>curScreen()+'|'+sessionStorage.getItem('ks_admin_ok'))); }
 }
 console.log('errs',errs); await b.close(); })();
