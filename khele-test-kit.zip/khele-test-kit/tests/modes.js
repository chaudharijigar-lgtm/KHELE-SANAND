const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs=[];
  // ── LINK MODE: phone → WhatsApp link → control laptop → LED tab ──
  const cctx = await b.newContext();
  const ctl = await cctx.newPage(); ctl.on('dialog',d=>d.accept()); ctl.on('pageerror',e=>errs.push('ctl '+e.message));
  await ctl.goto('http://localhost:8765/index.html'); await ctl.waitForTimeout(600);
  const info = await ctl.evaluate(()=>{ localStorage.setItem('ks_control','1'); localStorage.setItem('ks_pin',pinHash('1234')); sessionStorage.setItem('ks_admin_ok','1'); loadDemoData(); setSync({mode:'link',dbUrl:'',room:'',role:'control'}); { const s0=getStore(); let id=900; s0.events.filter(e=>!s0.athletes.some(a=>a.event===e.name)).forEach(e=>{ for(let i=0;i<4;i++) s0.athletes.push({id:id++,name:'Test '+id,bib:String(id),team:'Sanand',event:e.name,lane:i+1}); }); saveStore(s0); } const s=getStore(); const tr=s.events.find(e=>e.type==='track'&&e.status!=='completed'&&s.athletes.some(a=>a.event===e.name)); const fl=s.events.find(e=>e.type==='field'&&e.status!=='completed'&&s.athletes.some(a=>a.event===e.name)); return {tr:[tr.name,getRefUrl(tr)], fl:fl?[fl.name,getRefUrl(fl)]:null}; });
  const led = await cctx.newPage(); await led.goto('http://localhost:8765/index.html'); await led.waitForTimeout(600); await led.evaluate(()=>showScreen('led'));
  for (const [name,url] of [info.tr, info.fl].filter(Boolean)) {
    const ph = await (await b.newContext({viewport:{width:390,height:844}})).newPage(); ph.on('dialog',d=>d.accept()); ph.on('pageerror',e=>errs.push('phone '+e.message));
    await ph.goto(url); await ph.waitForTimeout(1200);
    const filled = await ph.evaluate(()=>{ let n=0; document.querySelectorAll('#ref-athletes-container input[id^="ref-t-"]').forEach((x,i)=>{ x.value=String(1150+i*9); n++; });
      document.querySelectorAll('#ref-athletes-container input[id^="rft-t"]').forEach((x,i)=>{ x.value=(5+((i*37)%100)/100).toFixed(2); n++; }); return n; });
    await ph.evaluate(()=>submitRefereeResults()); await ph.waitForTimeout(800);
    const link = await ph.evaluate(()=>{ const a=document.querySelector('a[href^="https://wa.me/"]'); const t=a?decodeURIComponent(a.href.split('text=')[1]||''):''; const m=t.match(/https?:\/\/\S+\?imp=\S+/); return m?m[0]:null; });
    console.log('  link?', link?link.slice(0,80)+'… len '+link.length:null);
    await ctl.goto(link); await ctl.waitForTimeout(1500);
    console.log('  toasts:', await ctl.evaluate(()=>[...document.querySelectorAll('.toast')].map(t=>t.textContent.trim()).join(' | ')), '| results keys', await ctl.evaluate(()=>Object.keys(getStore().results).join(',')));
    const ok = await ctl.evaluate(n=>(getStore().results[n]||[]).length, name);
    await led.waitForTimeout(800);
    const ledOk = await led.evaluate(n=>(getStore().results[n]||[]).length, name);
    console.log('LINK', name, '| inputs', filled, '| control got', ok, '| LED tab got', ledOk);
  }
  // ── SAME-DEVICE mode: referee panel on the laptop → LED tab ──
  await ctl.goto('http://localhost:8765/index.html'); await ctl.waitForTimeout(600);
  const nm = await ctl.evaluate(()=>{ setSync({mode:'local',dbUrl:'',room:'',role:'control'}); const s=getStore(); const ev=s.events.find(e=>e.type==='track'&&!(s.results[e.name]||[]).length&&s.athletes.some(a=>a.event===e.name)); showScreen('referee'); openRefEvent(ev.id); return ev.name; });
  await ctl.waitForTimeout(500);
  await ctl.evaluate(()=>{ document.querySelectorAll('#ref-athletes-container input[id^="ref-t-"]').forEach((x,i)=>x.value=String(1200+i*7)); submitRefereeResults(); });
  await led.waitForTimeout(1000);
  console.log('LOCAL', nm, '| LED tab got', await led.evaluate(n=>(getStore().results[n]||[]).length, nm), '| LED shows it:', await led.evaluate(n=>document.getElementById('led-screen').innerText.includes(n.split(' ').slice(-2).join(' ')), nm));
  console.log('errors', errs); await b.close();
})();
