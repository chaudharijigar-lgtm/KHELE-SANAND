const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(500);
  const cases={'9.58':'9.58','12.34':'12.34','10.8':'10.8','12.341':'12.35','12.340':'12.34','9.999':'10.00','47.3':'47.3','59.999':'1:00.00','1:43.25':'1:43.25','2:05.3':'2:05.3','27:43.22':'27:43.22','2:01:09':'2:01:09','1:02:03.45':'1:02:03.45','8.95m':'8.95 m','1.65m':'1.65 m','NM':'NM','1.23?':'1.23?','':'','00:00:12.34':'12.34'};
  const r=await p.evaluate(c=>Object.entries(c).map(([i,want])=>{ const got=resTxt(i); return (got===want?'ok  ':'BAD ')+JSON.stringify(i)+' → '+JSON.stringify(got)+(got===want?'':' (want '+want+')'); }),cases);
  console.log(r.join('\n')); if(r.some(x=>x.startsWith('BAD'))) console.log('Error: format mismatch'); console.log('errs',errs); await b.close(); })();
