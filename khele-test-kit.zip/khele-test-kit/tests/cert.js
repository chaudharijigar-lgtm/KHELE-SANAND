// Certificate design: settings card, merit / participation / blank, custom certificate, father name import, privacy
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1400, height: 900 } }); const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.accept());
  ctx.on('page', np => { if (np !== p) setTimeout(() => np.close().catch(() => {}), 500); });
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  const logo = 'data:image/png;base64,' + fs.readFileSync(path.join(__dirname, '..', 'app', 'icon-192.png')).toString('base64');
  const r = await p.evaluate(async (logo) => {
    localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); loadDemoData();
    const s = getStore(); s.settings.logo = logo; s.settings.meetName = 'Khele Sanand Athletics Meet 2027'; saveStore(s);
    showScreen('admin'); showPage('page-generate'); await new Promise(r => setTimeout(r, 1200));
    const out = { card: !!document.getElementById('kc-card') };
    // save settings through the card
    $('kc-brand').value = 'KHELE SANAND'; $('kc-from').value = '2027-02-24'; $('kc-to').value = '2027-02-28'; $('kc-theme').value = 'blue'; $('kc-sn0').value = 'Rajesh Patel'; $('kc-venue').value = 'Taluka Sports Complex, Sanand'; $('kc-sd0').value = 'President';
    saveCertCfg(true); const c = getStore().settings.cert; out.saved = c.theme + '|' + c.sigs[0].name + '|' + c.from;
    // father name via bulk import
    const ev = getStore().events[0].name; _bulk.kind = 'athletes';
    _bulk.preview = [{ status: 'ok', data: { name: 'Father Test', team: 'Sanand', event: ev, father: 'Mahesh Thakor', gender: 'Male' } }]; bulkImport();
    const a = getStore().athletes.find(x => x.name === 'Father Test'); out.father = a && a.father;
    out.pushHasFather = JSON.stringify(stateForPush(getStore())).includes('Mahesh Thakor');
    // preview pages
    const pv = pcBuild({ kind: 'certpreview' }); out.preview = pv.pages.length + '|' + pv.pages.every(x => x.includes('kscert')) + '|' + /@page\{size:A4 landscape;margin:0\}/.test(pv.css);
    const t = pv.pages[0]; out.merit = /Certificate <span>of<\/span> Merit/.test(t) && /won <b class="kc-medalword"[^>]*>Gold<\/b> medal/.test(t) && /24th February 2027/.test(t) && /Son of/.test(t) && /Mr\./.test(t);
    out.part = /Certificate <span>of<\/span> Participation/.test(pv.pages[1]) && /Daughter of/.test(pv.pages[1]) && /Ms\./.test(pv.pages[1]);
    out.venue = /organized at <span class="fld">Taluka Sports Complex, Sanand<\/span> from/.test(t);
    out.blank = /Mr\.\/Ms\./.test(pv.pages[2]) && /Son\/Daughter/.test(pv.pages[2]);
    // custom certificate (Kabaddi)
    const cu = pcBuild({ kind: 'custom', custom: { name: 'Arjun Rathod', gender: 'Male', father: 'Bharat Rathod', team: 'Moraiya', events: ['Under-14 Kabaddi (Boys)'], place: 2 } });
    out.custom = cu.pages.length === 1 && /Under-14 Kabaddi \(Boys\)/.test(cu.pages[0]) && />Silver</.test(cu.pages[0]) && /Moraiya/.test(cu.pages[0]);
    // real certificates from results use the new design
    const s2 = getStore(); const e2 = s2.events.find(e => s2.athletes.some(x => x.event === e.name)); const at = s2.athletes.filter(x => x.event === e2.name);
    s2.results[e2.name] = buildTrackEntries(at, x => ({ result: String(2250 + x.id * 37), flag: '' })); e2.status = 'completed'; saveStore(s2);
    const all = pcBuild({ kind: 'allcert', scope: 'all', prov: true, one: true, num: true, assign: true });
    out.all = all.pages.length + '|' + all.pages.every(x => x.includes('kscert')) + '|' + (all.css.includes('.kc-ribbon'));
    out.meetName = meetInfo().name;
    return out;
  }, logo);
  console.log(JSON.stringify(r));
  console.log('errs', errs); await b.close();
})();
