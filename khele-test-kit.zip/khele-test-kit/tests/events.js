// New event types in "Bulk Add Events → Generate"
const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('dialog',d=>d.accept());
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  const r=await p.evaluate(()=>{
    const want=['30m','50m','60m','Standing Broad Jump','Vertical Jump','Kids Javelin Throw','Softball Throw','Medicine Ball Throw'];
    const types=want.map(n=>n+'='+detectType(n)+(isVertical({name:n})?'/HEIGHTS':'')).join(', ');
    const A=[1,2,3].map(i=>({id:i,name:'A'+i,team:'T',event:'U-14 Boys Vertical Jump Final',lane:i}));
    const vj=buildFieldEntries(A,a=>({1:{t1:'0.45',t2:'0.48'},2:{t1:'0.52'},3:{t1:'X',s1:'foul'}}[a.id])).map(e=>e.name+':'+resTxt(e.result)+':'+e.rank).join(' ');
    const sp=buildTrackEntries([{id:1,name:'S',team:'T',event:'U-10 Boys 30m Final'}],a=>({result:'5.12',flag:''})).map(e=>resTxt(e.result)+':'+e.rank).join(' ');
    return {types, vj, sp};
  });
  // the generator list shows all of them
  await p.evaluate(()=>{ localStorage.setItem('ks_pin',pinHash('1234')); sessionStorage.setItem('ks_admin_ok','1'); });
  console.log(JSON.stringify(r));
  console.log('errs',errs); await b.close(); })();
