// Multi-live edge cases: main finished while a field event is still live; Live Sync to a Big View screen; referee on an "also live" event
const { chromium } = require('playwright');
const init = () => { window.KS_AUTH_BASE = { signUp: 'http://localhost:9000/signUp', refresh: 'http://localhost:9000/token' }; window.KS_ALLOW_ANY_DB = true; };
(async () => {
  const b = await chromium.launch(); const errs = [];
  const mk = async (tag, vp) => { const ctx = await b.newContext({ viewport: vp || { width: 1280, height: 800 } }); await ctx.addInitScript(init); const p = await ctx.newPage();
    p.on('dialog', d => d.accept()); p.on('pageerror', e => errs.push(tag + ': ' + e.message)); return p; };
  const out = {};
  // A) main finished, one also-live left (same device)
  const a = await mk('a', { width: 1920, height: 1080 });
  await a.goto('http://localhost:8765/index.html'); await a.waitForTimeout(700);
  Object.assign(out, await a.evaluate(async () => {
    localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); loadDemoData();
    const s = getStore(); const tr = s.events.find(e => e.type === 'track' && e.status !== 'completed'); const fl = s.events.find(e => e.type === 'field' && e.status !== 'completed');
    setLiveEvent(tr.id); addAlsoLive(fl.id);
    // finish the main event the normal way
    const s2 = getStore(); const ev = eventById(s2, s2.liveEventId); ev.status = 'completed'; s2.liveEventId = null; saveStore(s2);
    const o = {};
    const sl = buildFocusSlides(getStore()); o.aBig = /ALSO LIVE|LIVE NOW/.test(sl[0].html) && sl[0].html.includes(fl.name);
    showScreen('led'); renderDashboard(); o.aLed = document.getElementById('d-hero-name').textContent === fl.name;
    o.aList = liveList(getStore()).length;
    return o;
  }));
  // B) Live Sync: control → Big View screen on another device; referee on the also-live event
  const ctl = await mk('control');
  await ctl.goto('http://localhost:8765/index.html'); await ctl.waitForTimeout(700);
  const info = await ctl.evaluate(async () => {
    localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); localStorage.setItem('ks_control', '1'); loadDemoData();
    setSync({ mode: 'firebase', dbUrl: 'http://localhost:9000', room: 'ML' + Date.now(), role: 'control', apiKey: 'k' }); await connectSync();
    const s = getStore(); const tr = s.events.find(e => e.type === 'track' && e.status !== 'completed'); const fl = s.events.find(e => e.type === 'field' && e.status !== 'completed');
    let id = 900; for (let i = 0; i < 4; i++) s.athletes.push({ id: id++, name: 'Jumper ' + i, bib: String(800 + i), team: 'Sanand', event: fl.name, lane: i + 1 }); saveStore(s);
    setLiveEvent(tr.id); addAlsoLive(fl.id); await new Promise(r => setTimeout(r, 1500));
    return { big: displayUrl('big'), ref: getRefUrl(eventById(getStore(), fl.id)), fl: fl.name, flId: fl.id };
  });
  const big = await mk('big', { width: 1920, height: 1080 });
  await big.goto(info.big); await big.waitForTimeout(3000);
  out.bSplit = await big.evaluate(() => { const st = document.getElementById('fv-stage'); return !!(st && st.querySelector('.fs-grid')) && (st.querySelectorAll('.fs-col').length === 2); });
  // pin from control reaches the screen
  await ctl.evaluate(id => pinScreen(id), info.flId); await big.waitForTimeout(3000);
  out.bPin = await big.evaluate(() => document.querySelectorAll('#fv-stage .fv-slide').length === 1 && !document.querySelector('#fv-stage .fs-grid'));
  await ctl.evaluate(() => pinScreen(0)); await big.waitForTimeout(2500);
  out.bUnpin = await big.evaluate(() => !!document.querySelector('#fv-stage .fs-grid'));
  // referee on the also-live event submits FINAL → screen shows its final results (held 3 min)
  const ph = await mk('phone', { width: 390, height: 844 });
  await ph.goto(info.ref); await ph.waitForTimeout(2500);
  await ph.evaluate(() => { document.querySelectorAll('#ref-athletes-container input[id^="rft-t"]').forEach((x, i) => { x.value = (4 + i / 10).toFixed(2); }); submitRefereeResults(); });
  let got = false; for (let i = 0; i < 20 && !got; i++) { await big.waitForTimeout(1000); got = await big.evaluate(() => { const h = document.getElementById('fv-stage').innerHTML; return /FINAL RESULTS/.test(h) && /m<\/div>/.test(h); }); }
  out.bFinalShown = got;
  console.log(JSON.stringify(out)); console.log('errs', errs); await b.close();
})();
