const { chromium } = require('playwright');
const SP=process.env.KS_SHOTS;
const PAGES=['page-run','page-control','page-results','page-callroom','page-events','page-athletes','page-teams','page-records','page-generate','page-screen','page-waiting','page-ceremony','page-conditions','page-operations'];
const DIALOG=process.argv[2]||'dismiss';
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({viewport:{width:1440,height:900}, acceptDownloads:true});
  const p = await ctx.newPage();
  ctx.on('page', np=>{ if(np!==p) setTimeout(()=>np.close().catch(()=>{}),800); });
  const errs=[]; let where='load';
  p.on('pageerror',e=>errs.push(`[${where}] PAGEERROR ${e.message} | ${(e.stack||'').split('\n').slice(1,3).join(' ').replace(/http:\/\/localhost:8765\/index.html/g,'')}`));
  p.on('console',m=>{ if(m.type()==='error'&&!/net::ERR|Failed to load resource|favicon/.test(m.text())) errs.push(`[${where}] CONSOLE ${m.text().slice(0,250)}`); });
  p.on('dialog',d=>{ DIALOG==='accept'&&d.type()!=='prompt'?d.accept():d.dismiss(); });
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  await p.evaluate(()=>{ localStorage.setItem('ks_pin',pinHash('1234')); sessionStorage.setItem('ks_admin_ok','1'); loadDemoData(); });
  await p.reload(); await p.waitForTimeout(800);
  await p.evaluate(()=>{ sessionStorage.setItem('ks_admin_ok','1'); showScreen('admin'); });
  await p.waitForTimeout(800);
  let clicks=0;
  for (const pg of PAGES) {
    await p.evaluate(id=>{ document.querySelectorAll('.modal-overlay.open').forEach(m=>m.classList.remove('open')); showScreen('admin'); showPage(id, document.querySelector(`[onclick^="showPage('${id}'"]`)); }, pg);
    await p.waitForTimeout(400);
    await p.screenshot({path:`${SP}admin-${pg}.png`});
    const n = await p.evaluate(id=>{ const el=document.getElementById(id); const bs=[...el.querySelectorAll('button')].filter(b=>b.offsetParent&&!b.disabled);
      bs.forEach((b,i)=>b.setAttribute('data-fz',id+'-'+i)); return bs.length; }, pg);
    for (let i=0;i<n;i++){
      const sel=`[data-fz="${pg}-${i}"]`;
      const label = await p.evaluate(s=>{ const b=document.querySelector(s); return b&&b.offsetParent? (b.textContent.trim()||b.title||b.getAttribute('onclick')||'').slice(0,40):null; }, sel);
      if(!label) continue;
      if(/reset|wipe|factory|delete all|clear all|hand over|turn off live|lock admin|exit|demo/i.test(label)) continue;
      where=`${pg} › "${label}"`;
      try{ await p.click(sel,{timeout:1500, force:true}); clicks++; }catch(e){ }
      await p.waitForTimeout(250);
      await p.evaluate(()=>{ document.querySelectorAll('.modal-overlay.open').forEach(m=>m.classList.remove('open')); });
      const vis = await p.evaluate(()=>document.getElementById('admin-screen').classList.contains('active'));
      if(!vis){ await p.evaluate(id=>{ sessionStorage.setItem('ks_admin_ok','1'); showScreen('admin'); showPage(id); },pg); await p.waitForTimeout(300); }
    }
  }
  console.log('clicks',clicks);
  console.log([...new Set(errs)].join('\n')||'no errors');
  await b.close();
})();
