// Smart time entry: what referees type → what the app understands (and when "?" appears)
const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const p = await b.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(700);
  const r = await p.evaluate(() => {
    const cases = [['U-14 Boys 100m Final', '1050', '10.50'], ['U-14 Boys 100m Final', '10.50', '10.50'], ['U-14 Boys 100m Final', '10 sec 50', '10.50'], ['U-14 Boys 100m Final', '10s 50ms', '10.50'],
      ['U-17 Boys 800m Final', '1.50', '1:50'], ['U-17 Boys 800m Final', '150', '1:50'], ['U-17 Boys 800m Final', '1.50.20', '1:50.20'], ['U-17 Boys 800m Final', '15020', '1:50.20'],
      ['U-17 Boys 800m Final', '1 min 50 sec', '1:50'], ['U-17 Boys 800m Final', '1m 50s 20', '1:50.20'], ['U-17 Boys 800m Final', '1:50.2', '1:50.2'], ['U-19 Boys 1500m Final', '4.05.30', '4:05.30'],
      ['U-19 Boys 400m Final', '58.20', '58.20'], ['U-19 Boys 400m Final', '1.02', '1:02'], ['U-14 Boys 100m Final', '2.10', '2.10?'], ['U-14 Boys 100m Final', '12,34', '12.34'], ['U-17 Boys 800m Final', '2.10', '2:10'], ['U-17 Boys 200m Final', '2450', '24.50'],
      ['U-14 Boys 100m Final', '00:10.50', '00:10.50'], ['U-17 Boys 800m Final', '01:50.00', '01:50.00'], ['U-19 Boys 400m Final', '00:58.20', '00:58.20'],
      ['U-19 Men 10000m', '01:05:30.00', '1:05:30.00'], ['U-19 Men 10000m', '1053000', '1:05:30.00'], ['U-19 Men 10000m', '1.05.30.00', '1:05:30.00'], ['U-17 Boys 800m Final', '01:80.00', '01:80.00']];
    return cases.map(([ev, typed, want]) => { const e = buildTrackEntries([{ id: 1, name: 'A', team: 'T', event: ev }], () => ({ result: typed, flag: '' }))[0];
      const ok = e.result === want; return (ok ? 'ok  ' : 'BAD ') + ev.replace(/ Final/, '') + ' | ' + JSON.stringify(typed) + ' → ' + JSON.stringify(e.result) + (ok ? '' : ' (want ' + want + ')'); });
  });
  console.log(r.join('\n')); if (r.some(x => x.startsWith('BAD'))) console.log('Error: time entry mismatch'); console.log('errs', errs); await b.close(); })();
