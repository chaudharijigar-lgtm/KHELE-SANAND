const { chromium } = require('playwright');
const SP=process.env.KS_SHOTS;
(async () => {
  const b = await chromium.launch(); const errs=[];
  const ctl = await (await b.newContext()).newPage(); ctl.on('dialog',d=>d.accept());
  ctl.on('pageerror',e=>errs.push('ctl '+e.message));
  await ctl.goto('http://localhost:8765/index.html'); await ctl.waitForTimeout(800);
  const url = await ctl.evaluate(() => { loadDemoData(); setSync({mode:'link',dbUrl:'',room:'',role:'control'});
    const s=getStore(); const ev=s.events.find(e=>e.type!=='field'&&s.athletes.some(a=>a.event===e.name)); return getRefUrl(ev); });
  console.log('ref url len', url.length);
  async function phone(tag, firebase){
    const ctx = await b.newContext({viewport:{width:390,height:844}}); const p = await ctx.newPage();
    p.on('dialog',d=>d.accept()); p.on('pageerror',e=>errs.push(tag+' '+e.message));
    await p.goto(url); await p.waitForTimeout(1500);
    if(firebase) await p.evaluate(()=>{ const c=getSync(); c.mode='firebase'; c.dbUrl='http://127.0.0.1:1'; c.room='TEST'; c.role='referee'; localStorage.setItem('ks_sync',JSON.stringify(c)); setSync(c); sessionStorage.setItem('ks_refkey_'+_refEventId,'abc'); });
    const n = await p.evaluate(()=>{ let i=0; document.querySelectorAll('#ref-athletes-container input[id^="ref-t-"]').forEach(x=>{ x.value=String(1100+(i++)*7); }); return i; });
    await p.evaluate(()=>submitRefereeResults()); await p.waitForTimeout(1200);
    const st = await p.evaluate(()=>({ banner:!!document.getElementById('ref-ty-banner'), tyText:(document.body.innerText.match(/THANK YOU!/)||[])[0]||null,
      status:(document.getElementById('ref-ty-status')||{}).textContent||null,
      enabledInputs:[...document.querySelectorAll('#ref-result-panel input')].filter(i=>!i.disabled&&i.offsetParent).length,
      submitVisible:[...document.querySelectorAll('#ref-result-panel button')].some(b=>/SUBMIT/.test(b.textContent)&&b.offsetParent),
      wa:!!document.querySelector('a[href^="https://wa.me/"]') }));
    console.log(tag,'inputs',n,JSON.stringify(st));
    await p.screenshot({path:SP+tag+'.png'});
    await p.reload(); await p.waitForTimeout(1500);
    const st2 = await p.evaluate(()=>({ty:/THANK YOU!|RESULTS SUBMITTED/.test(document.body.innerText), enabledInputs:[...document.querySelectorAll('#ref-result-panel input')].filter(i=>!i.disabled&&i.offsetParent).length}));
    console.log(tag,'after reload',JSON.stringify(st2));
    await p.screenshot({path:SP+tag+'-reload.png'});
    await ctx.close();
  }
  await phone('link', false);
  await phone('fb', true);
  // provisional must stay editable
  { const ctx = await b.newContext(); const p = await ctx.newPage(); p.on('dialog',d=>d.accept());
    await p.goto(url); await p.waitForTimeout(1500);
    await p.evaluate(()=>{ document.querySelectorAll('#ref-athletes-container input[id^="ref-t-"]').forEach((x,i)=>x.value=String(1200+i)); const f=document.getElementById('rp-final'); if(f) f.checked=false; submitRefereeResults(); });
    await p.waitForTimeout(800);
    console.log('provisional banner?', await p.evaluate(()=>!!document.getElementById('ref-ty-banner')||/THANK YOU!/.test(document.body.innerText)));
    await ctx.close(); }
  console.log('errors', errs); await b.close();
})();
