// Drive / web photo links in bulk athlete import
const { chromium } = require('playwright'); const http=require('http'), fs=require('fs'), path=require('path');
(async()=>{
  // a server WITHOUT CORS headers (like many websites) on 9100
  const png=fs.readFileSync(path.join(__dirname,'..','app','icon-192.png'));
  const srv=http.createServer((q,r)=>{ r.writeHead(200,{'Content-Type':'image/png'}); r.end(png); }).listen(9100);
  const b=await chromium.launch(); const p=await (await b.newContext()).newPage(); const errs=[];
  p.on('pageerror',e=>errs.push(e.message)); p.on('dialog',d=>d.accept());
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  const ids=await p.evaluate(()=>['https://drive.google.com/file/d/1AbCdEfGhIjKlMnOpQ/view?usp=sharing','https://drive.google.com/open?id=1AbCdEfGhIjKlMnOpQ','https://drive.google.com/uc?export=view&id=1AbCdEfGhIjKlMnOpQ','https://drive.google.com/drive/folders/1Folder123456','hello'].map(u=>driveId(u)));
  console.log('driveId', JSON.stringify(ids));
  const r=await p.evaluate(async()=>{
    loadDemoData(); const s=getStore(); const ev=s.events[0].name;
    _bulk.kind='athletes';
    _bulk.preview=[
      {status:'ok',data:{name:'Photo Same Origin',team:'Sanand',event:ev,photo:location.origin+'/icon-192.png'}},
      {status:'ok',data:{name:'Photo No Cors',team:'Sanand',event:ev,photo:'http://localhost:9100/x.png'}},
      {status:'ok',data:{name:'Photo Folder',team:'Sanand',event:ev,photo:'https://drive.google.com/drive/folders/1Folder123456'}},
      {status:'ok',data:{name:'Photo Broken',team:'Sanand',event:ev,photo:'http://localhost:9100.invalid/x.png'}},
      {status:'ok',data:{name:'No Photo',team:'Sanand',event:ev,photo:''}}];
    bulkImport();
    for(let i=0;i<120&&!(document.getElementById('photo-job')||{}).textContent?.includes('done');i++) await new Promise(r=>setTimeout(r,250));
    const st=getStore(); const get=n=>{ const a=st.athletes.find(x=>x.name===n); const v=a&&PhotoDB.cache[photoKey(a)]; return v?(v.startsWith('data:image/jpeg')?'saved':v.startsWith('http')?'link':'other'):'none'; };
    return {same:get('Photo Same Origin'), nocors:get('Photo No Cors'), folder:get('Photo Folder'), broken:get('Photo Broken'), none:get('No Photo'), box:document.getElementById('photo-job').innerText.replace(/\s+/g,' ').slice(0,300), imported:st.athletes.filter(a=>/Photo|No Photo/.test(a.name)).length};
  });
  console.log(JSON.stringify(r));
  console.log('errs',errs); await b.close(); srv.close();
})();
