// Minimal mock of Firebase Realtime Database REST + streaming + anonymous auth, for testing.
const http = require('http');
let db = {};
let subs = []; // {path:[...], res}
let fail503 = 0;
let uid = 0;
let stats = {writes:{}, writeBytes:0, sseBytes:0, sseEvents:0, gets:0, streams:0};
const now = () => Date.now();
const split = p => p.replace(/^\/+|\/+$/g, '').split('/').filter(Boolean).map(decodeURIComponent);
function get(path) { let o = db; for (const k of path) { if (o == null || typeof o !== 'object') return null; o = o[k]; } return o === undefined ? null : o; }
function sv(v) { if (v && typeof v === 'object') { if (v['.sv'] === 'timestamp') return now(); for (const k in v) v[k] = sv(v[k]); } return v; }
function prune(o) { if (o && typeof o === 'object') { for (const k of Object.keys(o)) { o[k] = prune(o[k]); if (o[k] == null || (typeof o[k] === 'object' && !Object.keys(o[k]).length)) delete o[k]; } } return o; }
function set(path, v) {
  if (!path.length) { db = v || {}; }
  else { let o = db; for (const k of path.slice(0, -1)) { if (o[k] == null || typeof o[k] !== 'object') o[k] = {}; o = o[k]; } if (v == null) delete o[path[path.length - 1]]; else o[path[path.length - 1]] = v; }
  prune(db); notify(path);
}
function notify(path) {
  for (const s of subs) {
    const a = s.path, n = Math.min(a.length, path.length);
    if (a.slice(0, n).join('/') !== path.slice(0, n).join('/')) continue;
    if (path.length >= a.length) { const rel = '/' + path.slice(a.length).join('/'); send(s.res, 'put', { path: rel, data: get(path) }); }
    else send(s.res, 'put', { path: '/', data: get(a) });
  }
}
function send(res, ev, data) { try { const t=`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`; stats.sseBytes+=t.length; if(ev!=='keep-alive') stats.sseEvents++; res.write(t); } catch { } }
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,PUT,PATCH,POST,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  let body = ''; req.on('data', c => body += c); req.on('end', () => {
    const J = (code, obj) => { res.writeHead(code, { ...cors, 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
    if (u.pathname === '/signUp') { uid++; return J(200, { idToken: 'tok' + uid, refreshToken: 'r' + uid, localId: 'uid' + uid, expiresIn: '3600' }); }
    if (u.pathname === '/token') { const m = /refresh_token=r(\d+)/.exec(body); return J(200, { id_token: 'tok' + (m ? m[1] : 0), refresh_token: 'r' + (m ? m[1] : 0), user_id: 'uid' + (m ? m[1] : 0), expires_in: '3600' }); }
    if (u.pathname === '/__outage') { fail503 = +(u.searchParams.get('n') || 3); subs.forEach(s => { try { s.res.destroy(); } catch { } }); subs = []; return J(200, { ok: 1 }); }
    if (u.pathname === '/__dump') return J(200, db);
    if (u.pathname === '/__stats') { const r=JSON.parse(JSON.stringify(stats)); if(u.searchParams.get('reset')) stats={writes:{}, writeBytes:0, sseBytes:0, sseEvents:0, gets:0, streams:0}; return J(200, r); }
    if (!u.pathname.endsWith('.json')) return J(404, { error: 'nf' });
    const path = split(u.pathname.slice(0, -5));
    if (req.method === 'GET' && /text\/event-stream/.test(req.headers.accept || '')) {
      if (fail503 > 0) { fail503--; res.writeHead(503, cors); return res.end('down'); }
      res.writeHead(200, { ...cors, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      stats.streams++; const s = { path, res }; subs.push(s); send(res, 'put', { path: '/', data: get(path) });
      const ka = setInterval(() => send(res, 'keep-alive', null), 30000);
      res.on('close', () => { clearInterval(ka); subs = subs.filter(x => x !== s); });
      return;
    }
    if (req.method === 'GET') { stats.gets++; return J(200, get(path)); }
    let v = null; try { v = body ? JSON.parse(body) : null; } catch { return J(400, { error: 'bad json' }); }
    v = sv(v); if(req.method!=='DELETE'){ const key=path.slice(2,3).join('/')||'root'; stats.writes[key]=(stats.writes[key]||0)+1; stats.writeBytes+=body.length; }
    if (req.method === 'PUT') { set(path, v); return J(200, v); }
    if (req.method === 'PATCH') { for (const k in v) set([...path, ...split(k)], v[k]); return J(200, v); }
    if (req.method === 'DELETE') { set(path, null); return J(200, null); }
    J(405, {});
  });
}).listen(9000, () => console.log('mock on 9000'));
