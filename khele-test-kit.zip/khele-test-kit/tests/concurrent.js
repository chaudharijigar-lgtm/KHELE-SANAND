// Several referee phones submit results for different events at the same moment (Live Sync)
const { chromium } = require('playwright');
const init = () => { window.KS_AUTH_BASE = { signUp: 'http://localhost:9000/signUp', refresh: 'http://localhost:9000/token' }; window.KS_ALLOW_ANY_DB = true; };
(async () => {
  const b = await chromium.launch(); const errs = [];
  const mk = async (tag, vp) => { const ctx = await b.newContext({ viewport: vp || { width: 1280, height: 800 } }); await ctx.addInitScript(init); const p = await ctx.newPage();
    p.on('dialog', d => d.accept()); p.on('pageerror', e => errs.push(tag + ': ' + e.message)); p.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errs.push(tag + ' console: ' + m.text().slice(0, 160)); }); return p; };
  const ctl = await mk('control');
  await ctl.goto('http://localhost:8765/index.html'); await ctl.waitForTimeout(700);
  const info = await ctl.evaluate(async () => {
    localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); localStorage.setItem('ks_control', '1'); loadDemoData();
    const s = getStore(); let id = 900;
    const evs = s.events.filter(e => e.status !== 'completed' && e.type !== 'ceremony').slice(0, 5);
    evs.forEach((e, k) => { if (!s.athletes.some(a => a.event === e.name)) for (let i = 0; i < 6; i++) s.athletes.push({ id: id++, name: 'Ath ' + k + '-' + i, bib: String(500 + id), team: ['Sanand', 'Bopal', 'Moraiya'][i % 3], event: e.name, lane: i + 1 }); });
    saveStore(s);
    setSync({ mode: 'firebase', dbUrl: 'http://localhost:9000', room: 'CC' + Date.now(), role: 'control', apiKey: 'k' }); await connectSync();
    setLiveEvent(evs[0].id); evs.slice(1).forEach(e => addAlsoLive(e.id));
    await new Promise(r => setTimeout(r, 1500));
    return { evs: evs.map(e => ({ id: e.id, name: e.name, type: e.type, url: getRefUrl(e) })), led: displayUrl('led') };
  });
  const led = await mk('led', { width: 1920, height: 1080 }); await led.goto(info.led); await led.waitForTimeout(2500);
  const phones = [];
  for (const e of info.evs) { const p = await mk('phone-' + e.id, { width: 390, height: 844 }); await p.goto(e.url); phones.push([p, e]); }
  await Promise.all(phones.map(([p]) => p.waitForFunction(() => document.querySelectorAll('#ref-athletes-container input').length > 0, null, { timeout: 30000 }).catch(() => {})));
  // fill everything, then press SUBMIT on all phones at the same moment
  await Promise.all(phones.map(([p, e]) => p.evaluate(type => {
    let i = 0; document.querySelectorAll('#ref-athletes-container input[id^="ref-t-"]').forEach(x => { x.value = String(2300 + (i++) * 41); });
    document.querySelectorAll('#ref-athletes-container input[id^="rft-t"]').forEach((x, k) => { x.value = (4 + (k % 9) / 10).toFixed(2); });
  }, e.type)));
  await Promise.all(phones.map(([p]) => p.evaluate(() => submitRefereeResults())));
  const want = info.evs.map(e => e.name);
  let ok = null; for (let i = 0; i < 25; i++) { await ctl.waitForTimeout(1000); ok = await ctl.evaluate(w => w.map(n => (getStore().results[n] || []).length), want); if (ok.every(n => n > 0)) break; }
  await ctl.waitForTimeout(5000);
  const ledOk = await led.evaluate(w => w.map(n => (getStore().results[n] || []).length), want);
  const green = await Promise.all(phones.map(([p]) => p.evaluate(() => /Sent to the control room|SAVED|RESULTS RECEIVED|RESULTS SUBMITTED/.test(document.body.innerText))));
  let closed = []; for (let i = 0; i < 15; i++) { closed = await ctl.evaluate(ids => ids.map(id => refClosed(id)), info.evs.map(e => e.id)); if (closed.every(Boolean)) break; await ctl.waitForTimeout(1000); }
  const phoneText = await Promise.all(phones.map(([p]) => p.evaluate(() => (document.getElementById('ref-ty-status') || {}).textContent || document.body.innerText.slice(0, 80).replace(/\s+/g, ' '))));
  console.log(JSON.stringify(phoneText));
  const dbgEv = await ctl.evaluate(ids => ids.map(id => { const s = getStore(), e = eventById(s, id), m = resMeta(s, e.name); return e.status + '/' + (m ? (m.provisional ? 'prov' : 'off') + '/' + m.src : '-'); }), info.evs.map(e => e.id));
  console.log('dbgEv', JSON.stringify(dbgEv));
  console.log(JSON.stringify({ control: ok, led: ledOk, phonesGreen: green, autoClosed: closed }));
  console.log('errs', errs); await b.close();
})();
