// Several events live at once: Big View slides, LED rotation, pin, setLiveEvent keeps "also live"
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 1920, height: 1080 } }); const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.accept());
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  const r = await p.evaluate(async () => {
    localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); loadDemoData();
    const s = getStore(); const tr = s.events.find(e => e.type === 'track' && e.status !== 'completed'); const fl = s.events.filter(e => e.type === 'field' && e.status !== 'completed');
    setLiveEvent(tr.id); addAlsoLive(fl[0].id); addAlsoLive(fl[1] ? fl[1].id : fl[0].id);
    const out = {}; const s1 = getStore();
    out.live = liveList(s1).map(e => e.type).join(',');
    const sp = buildFocusSlides(s1); out.split = sp[0].key + '|' + /fs-grid n3/.test(sp[0].html) + '|' + (sp[0].html.match(/fs-col/g) || []).length + '|' + (sp[0].html.match(/id="fv-timer"/g) || []).length;
    setLiveView('rotate'); const s1b = getStore();
    const sl = buildFocusSlides(s1b); out.slides = sl.filter(x => x.key.startsWith('live')).length + '|' + sl.filter(x => /ALSO LIVE/.test(x.html)).length + '|' + (sl.filter(x => /id="fv-timer"/.test(x.html)).length);
    setLiveOnly(true); out.liveOnly = buildFocusSlides(getStore()).length; setLiveOnly(false); setLiveView('split');
    showScreen('public'); await new Promise(r => setTimeout(r, 300)); out.pub = (document.getElementById('public-screen').innerText.match(/ALSO LIVE/g) || []).length; showScreen('admin');
    // rotation: different events at different times
    const orig = syncNow; const seen = new Set(); for (let t = 0; t < 6; t++) { window.syncNow = () => t * liveRotateSec() * 1000 + 5; seen.add(screenEventId(getStore())); } window.syncNow = orig; out.rotates = seen.size;
    // LED shows the alternate event
    showScreen('led'); await new Promise(r => setTimeout(r, 300));
    pinScreen(fl[0].id); renderDashboard(); out.ledPinned = document.getElementById('d-hero-name').textContent === fl[0].name && document.getElementById('led-screen').classList.contains('alt-live');
    out.pinSlides = buildFocusSlides(getStore()).length;
    pinScreen(0); out.unpinned = getStore().screenFocus === 0;
    // change main live → also-live stay live
    const tr2 = getStore().events.find(e => e.type === 'track' && e.status !== 'completed' && e.id !== tr.id); setLiveEvent(tr2.id);
    out.afterSwitch = liveList(getStore()).length + '|' + (getStore().liveEventId === tr2.id) + '|' + eventById(getStore(), fl[0].id).status;
    removeAlsoLive(fl[0].id, true); out.finished = eventById(getStore(), fl[0].id).status + '|' + liveList(getStore()).length;
    showScreen('admin'); showPage('page-run'); await new Promise(r => setTimeout(r, 500)); out.card = !!document.getElementById('ml-card');
    return out;
  });
  await p.screenshot({ path: (process.env.KS_SHOTS || '/tmp/ks-shots/') + 'multilive-admin.png' });
  console.log(JSON.stringify(r)); console.log('errs', errs); await b.close();
})();
