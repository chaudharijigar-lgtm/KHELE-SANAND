const { chromium } = require('playwright');
const SP=process.env.KS_SHOTS;
require('fs').mkdirSync(SP,{recursive:true});
const PAGES=['page-run','page-control','page-results','page-callroom','page-events','page-athletes','page-teams','page-records','page-generate','page-screen','page-waiting','page-ceremony','page-conditions','page-operations'];
(async () => {
  const b = await chromium.launch();
  for (const [vw,vh,tag] of [[1920,1080,'led'],[390,844,'phone']]) {
    const ctx = await b.newContext({viewport:{width:vw,height:vh}}); const p = await ctx.newPage();
    const errs=[]; let where='load';
    p.on('pageerror',e=>errs.push(`[${where}] PAGEERROR ${e.message} @ ${(e.stack||'').split('\n')[1]||''}`));
    p.on('console',m=>{ if(m.type()==='error') errs.push(`[${where}] CONSOLE ${m.text().slice(0,200)}`); });
    p.on('dialog',d=>d.accept());
    await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
    where='demo'; await p.evaluate(()=>loadDemoData()); await p.waitForTimeout(500);
    for (const sc of ['led','waiting','focus','public','wall','referee','admin']) {
      where='screen:'+sc;
      await p.evaluate(s=>{ try{ showScreen(s); }catch(e){ console.error('showScreen '+s+' '+e.message); } }, sc);
      await p.waitForTimeout(1200);
      const ov = await p.evaluate(()=>({sw:document.documentElement.scrollWidth, w:innerWidth}));
      if (ov.sw>ov.w+2) errs.push(`[${where}] horizontal overflow ${ov.sw}>${ov.w}`);
      await p.screenshot({path:`${SP}${tag}-${sc}.png`});
    }
    for (const pg of PAGES) {
      where='admin:'+pg;
      await p.evaluate(id=>{ const el=document.querySelector(`[onclick^="showPage('${id}'"]`); try{ showPage(id, el); }catch(e){ console.error('showPage '+e.message); } }, pg);
      await p.waitForTimeout(500);
      const ov = await p.evaluate(id=>{ const el=document.getElementById(id); const out=[]; if(el) el.querySelectorAll('*').forEach(x=>{ const r=x.getBoundingClientRect(); if(r.width>0&&r.right>innerWidth+4&&getComputedStyle(x).position!=='fixed') out.push((x.id||x.className||x.tagName).toString().slice(0,40)+':'+Math.round(r.right)); }); return out.slice(0,5); }, pg);
      if (ov.length && tag==='phone') errs.push(`[${where}] elements past screen edge: ${ov.join(', ')}`);
      await p.screenshot({path:`${SP}${tag}-${pg}.png`});
    }
    console.log('=== '+tag+' ==='); console.log([...new Set(errs)].join('\n')||'no errors');
    await ctx.close();
  }
  await b.close();
})();
