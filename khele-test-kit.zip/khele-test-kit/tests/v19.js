// Live Control page: also-live timers, ➕ Also live in the picker, keep-both prompt; Big View corner tab; version label
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = []; const ctx = await b.newContext({ viewport: { width: 1600, height: 900 } }); const p = await ctx.newPage();
  p.on('pageerror', e => errs.push(e.message)); let dlg = 0; p.on('dialog', d => { dlg++; d.accept(); });
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(700);
  const out = {};
  out.verHome = await p.evaluate(() => (document.querySelector('#launcher .ks-ver') || {}).textContent || 'none');
  const ids = await p.evaluate(() => { localStorage.setItem('ks_pin', pinHash('1234')); sessionStorage.setItem('ks_admin_ok', '1'); loadDemoData();
    const s = getStore(); const evs = s.events.filter(e => e.status !== 'completed' && e.type !== 'ceremony');
    const tr = evs.find(e => e.type === 'track'), fl = evs.find(e => e.type === 'field'), f2 = evs.filter(e => e.type === 'field')[1] || evs.find(e => e.id !== tr.id && e.id !== fl.id);
    showScreen('admin'); showPage('page-control'); setLiveEvent(tr.id); renderEventPicker(); return { tr: tr.id, fl: fl.id, f2: f2.id }; });
  await p.waitForTimeout(300);
  out.verAdmin = await p.evaluate(() => ($('a-ver') || {}).textContent || 'none');
  out.alsoBtn = await p.evaluate(id => !!document.querySelector(`#a-event-picker button.al-btn[onclick*="addAlsoLive(${id})"]`), ids.fl);
  await p.click(`#a-event-picker button.al-btn[onclick*="addAlsoLive(${ids.fl})"]`); await p.waitForTimeout(400);
  out.mainKept = await p.evaluate(ids => getStore().liveEventId === ids.tr && (getStore().alsoLive || []).includes(ids.fl), ids);
  out.lccRow = await p.evaluate(id => !!document.querySelector(`#lcc-also button[onclick="evTimerStart(${id})"]`), ids.fl);
  await p.click(`#lcc-also button[onclick="evTimerStart(${ids.fl})"]`); await p.waitForTimeout(2300);
  out.lccTime = await p.evaluate(id => document.querySelector(`#lcc-also .evt-t[data-evt="${id}"]`).textContent, ids.fl);
  out.pauseShown = await p.evaluate(id => !!document.querySelector(`#lcc-also button[onclick="evTimerPause(${id})"]`), ids.fl);
  out.mainZero = await p.evaluate(() => $('a-elapsed').textContent);
  // main timer runs → clicking another event asks; OK keeps both
  await p.evaluate(() => startTimer()); await p.waitForTimeout(500);
  await p.evaluate(id => { const row = [...document.querySelectorAll('#a-event-picker div[onclick]')].find(d => d.getAttribute('onclick') === `controlLiveClick(${id})`); row.click(); }, ids.f2); await p.waitForTimeout(400);
  out.keepBoth = await p.evaluate(ids => [dlgCount = 0, getStore().liveEventId === ids.tr, (getStore().alsoLive || []).includes(ids.f2), _localTimer.running].slice(1).join('|'), ids);
  out.dialogs = dlg;
  // Big View: corner tab visible when the bar is hidden, takes you back
  await p.evaluate(() => showScreen('focus')); await p.waitForTimeout(7000);
  out.tab = await p.evaluate(() => { const t = $('fv-tab'); return t ? getComputedStyle(t).display + '|' + getComputedStyle(document.querySelector('#focus-screen .fv-ctrl')).opacity : 'none'; });
  await p.mouse.move(30, 25); await p.waitForTimeout(300); await p.click('#focus-screen .fv-back'); await p.waitForTimeout(300); out.tabBack = await p.evaluate(() => curScreen());
  out.timers = await p.evaluate(ids => { const s = getStore(); return [fmtElapsed(evElapsed(s, ids.fl)) !== '00:00.00', fmtElapsed(elapsedMs()) !== '00:00.00'].join('|'); }, ids);
  // the green "Live" button on a row also asks (no silent replace)
  await p.evaluate(() => showScreen('admin')); await p.waitForTimeout(300);
  const before = dlg; const other = await p.evaluate(() => { const s = getStore(); const e = s.events.find(e => e.status !== 'completed' && e.type !== 'ceremony' && e.id !== s.liveEventId && !(s.alsoLive || []).includes(e.id)); return e && e.id; });
  if (other) { await p.click(`#a-event-picker button[onclick="event.stopPropagation();controlLiveClick(${other})"]`); await p.waitForTimeout(400); }
  out.liveBtn = [dlg > before, await p.evaluate(id => (getStore().alsoLive || []).includes(id), other), await p.evaluate(() => !!document.querySelector('#a-event-picker button[title^="Make this the main"]'))].join('|');
  console.log(JSON.stringify(out)); console.log('errs', errs); await b.close();
})();
