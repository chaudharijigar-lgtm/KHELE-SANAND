const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext()).newPage(); p.on('dialog',d=>d.accept());
  const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto('http://localhost:8765/index.html'); await p.waitForTimeout(800);
  const r = await p.evaluate(() => {
    const out={};
    const A=(ev)=>[1,2,3,4,5].map(i=>({id:i,name:'A'+i,team:'T'+i,event:ev,lane:i}));
    const tr={1:{t1:'6.50',t2:'6.20',t3:'X',s3:'foul'},2:{t1:'6.20',t2:'6.50',s3:'foul'},3:{t1:'6.10'},4:{t1:'X',s1:'foul'},5:{t1:'6.50',t2:'6.30'}};
    out.fieldTie=buildFieldEntries(A('Long Jump (U-17)'),a=>tr[a.id]).map(e=>e.name+':'+e.result+':'+e.rank).join(' ');
    out.track100=buildTrackEntries(A('U-17 Boys 100m Final'),a=>({result:{1:'1234',2:'123',3:'12.34',4:'',5:'1:75.00'}[a.id],flag:a.id===4?'dnf':''})).map(e=>e.name+':'+e.result+':'+e.rank+(e.invalid?':INVALID':'')).join(' ');
    out.track1500=buildTrackEntries(A('U-19 1500m'),a=>({result:{1:'41234',2:'1234',3:'4:05.10',4:'',5:''}[a.id],flag:''})).map(e=>e.name+':'+e.result+':'+e.rank+(e.invalid?':INVALID':'')).join(' ');
    out.relay=buildTrackEntries(A('4x100m Relay U-17'),a=>({result:{1:'4512',2:'3000',3:'',4:'',5:''}[a.id],flag:''})).map(e=>e.name+':'+e.result+':'+e.rank+(e.invalid?':INVALID':'')).join(' ');
    out.dist=['U-17 Boys 100m Final','U-17 Girls 200m Final','4x400m Relay','U-15 Boys 100m Heat 1','110m Hurdles','3000 m Steeplechase','U-17 Shot Put','5000 Meter'].map(n=>n+'='+raceDistance(n)).join(', ');
    out.parse=['1:75.00','1:02.34','12.34','2:05:30'].map(v=>v+'='+parseTime(v)).join(', ');
    return out;
  });
  console.log(JSON.stringify(r,null,1)); console.log('errs',errs); await b.close();
})();
